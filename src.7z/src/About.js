import React from 'react'

function About() {
  return (
    <React.Fragment>
        <h1 style={{textAlign: 'center', marginTop: '20px'}}>About</h1>
        <p style={{textAlign: 'center'}}>This is the Todo List app v1.0.0. It is part of a React crash course.
        </p>
    </React.Fragment>
  )
}
export default About;